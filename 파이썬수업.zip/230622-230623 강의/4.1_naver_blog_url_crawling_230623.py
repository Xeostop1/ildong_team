from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome('chromedriver.exe')
driver.get('https://www.naver.com')
keyword = '블루투스 스피커'

#driver.find_element_by_id =>
driver.find_element(By.ID, 'query').send_keys(keyword+'\n')
#driver.find_element_by_xpath("//a[contains(text(), 'VIEW')]").click()
driver.find_element(By.XPATH, "//a[contains(text(), 'VIEW')]").click()
blogs_link = []

for page_i in range(1, 10+1):
    print("%s 페이지" % page_i)
    content = driver.page_source
    soup = BeautifulSoup(content, 'lxml')
    try:
        blogs = soup.find('div', {'class': 'api_subject_bx'}).find_all("li", "_svp_item")
        #blogs = soup.find('ul', {'id': 'elThumbnailResultArea'}).find_all("li", "sh_blog_top")
        for blog in blogs:
            print("ADD: %s" % blog.find("a", {'class':'total_dsc'})['href'])
            blogs_link.append(blog.find("a")['href'])
            exit(0)
        #driver.find_element_by_tag_name('body').send_keys(Keys.PAGE_DOWN)
        driver.find_element(By.TAG_NAME, 'body').send_keys(Keys.PAGE_DOWN)
        
        #elements = driver.find_element_by_class_name('paging').find_elements_by_xpath("*")
        # elements = driver.find_element(By.CLASS_NAME, 'paging').find_elements(By.XPATH, "*")
        # for element_i in range(len(elements)):
        #     if elements[element_i].tag_name == 'strong':
        #         try:
        #             elements[element_i+1].click()
        #             break
        #         except:
        #             driver.quit()
        time.sleep(1)
    except Exception as e:
        print(str(e))

for blog_link in blogs_link:
    with open('blog_url.txt', 'a') as fa:
        fa.write(blog_link+'\n')
driver.quit()
