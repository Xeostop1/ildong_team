#cgv.co.kr/movies/detail-view/?midx=87045#3
import requests
import json
import time
url = 'http://www.cgv.co.kr/common/ajax/point.aspx/GetMoviePointVariableList'

in_headers = {
    'content-type': 'application/json; charset=UTF-8',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36',
    'cookie': 'ASP.NET_SessionId=5kzazj2gtasupalvod2u0s0c; WMONID=jDaFPnGw66k; SL_G_WPT_TO=ko; _gid=GA1.3.1267401777.1687507543; _gat_UA-47951671-5=1; _gat_UA-47951671-7=1; _gat_UA-47126437-1=1; SL_GWPT_Show_Hide_tmp=1; SL_wptGlobTipTmp=1; _ga=GA1.1.1200256014.1687507543; _ga_SSGE1ZCJKG=GS1.3.1687507543.1.0.1687507543.0.0.0; _ga_559DE9WSKZ=GS1.1.1687507543.1.0.1687507546.57.0.0; CgvCM=qNdL1pU8O43mDL1sPJs5CLo5JLubb4svBJvFaT+dfcGhCeqB5IOIqPYODwL2BA9rnsVVMhFrUmLWwuXz3/haB0LJtzRau8uIh+rf+DwA8fDNTtjOY/cliyEASWVcHBBM/IXCnP14lc109jU65w37ij3qgjlYifbWyVjWTDy52jvtg4ySrVwpoZk6ZG2S54sY3T3uuXyN9ELMwDsBfSeP35Xmq2y0nddv468h8SGl5M5/uzgjESOsUvdMqwu1+ywv'}
for page in range(1, 100):
    post_data = """{'movieIdx': 87045, 'pageIndex': %s, 'pageSize': 20, 'orderType': 0, 'filterType': 1, 'isTotalCount' : false, 'isMyPoint' : 'false' }""" % page
    r = requests.post(url, data=post_data, headers=in_headers)
    content = r.text
    json_data = json.loads(content)
    #print(json_data)
    a = "{"+json_data['d'][json_data['d'].find("\"List"):]
    #print(a)
    a_json = json.loads(a)['List']
    #print(a_json)

    for review in a_json:
        try:
            print(page, review['CommentIdx'], review['CommentText'])
        except:
            print(page, "ERR")
    time.sleep(3)