import requests
from bs4 import BeautifulSoup

#https://cafe.naver.com/cosmania
url = 'https://cafe.naver.com/ArticleList.nhn?search.clubid=10050813&search.menuid=31&search.boardtype=L'
soup = BeautifulSoup(requests.get(url).text, 'lxml')

soup2 = soup.find_all("div", "article-board m-tcol-c")[1].find("tbody")

tr_list = soup2.find_all('tr', recursive=False)
fw = open('data.csv', 'w', encoding='cp949')

for tr in tr_list:
    num = tr.find("div", "inner_number").text
    try:
        link = tr.find("a", "article")['href'].strip()
    except:
        link = ""
    try:
        title = tr.find("a", "article").text.strip()
    except:
        title = ""
    date = tr.find("td", "td_date").text
    view = tr.find("td", "td_view").text
    likes = tr.find("td", "td_likes").text
    row = "%s,%s,\"%s\",%s,%s,%s" % (num, link, title, date, view, likes)
    print(row)
    fw.write(row+"\n")
fw.close()

