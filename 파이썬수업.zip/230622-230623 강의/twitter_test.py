import pandas as pd
import snscrape.modules.twitter as sntwitter
import re
#from cleantext import clean

# Keyword & date range
query = "유산균 until:2023-06-03 since:2023-06-01"
#query = "러시아"
tweets = []
# Maximum tweets to be scraped
limit = 5
# keyword check, because some tweet may be don't have the keyword that we want
check = "유산균"
try:
    data = sntwitter.TwitterSearchScraper(query).get_items()
except Exception as e:
    print(str(e))
for i, tweet in enumerate(data):
    try:
        print(i, tweet)
        if len(tweets) == limit:
            break
        else :
            content = tweet.content.split()
            #if check in content:
            if True:
                # remove emoji
                #clean_tweet = clean(tweet.content, no_emoji=True)
                # remove line break
                clean_tweet = tweet.content.replace("\n", " ")
                # remove hashtag
                clean_tweet = re.sub(r"#(\w+)", "", clean_tweet)
                # remove annoying data
                clean_tweet = re.sub(r"(?:\@|https?\://)\S+", "", clean_tweet)
                # remove whitespace
                clean_tweet = " ".join(clean_tweet.split())
                # just use the tweet and date
                print(tweet.date, clean_tweet)
                tweets.append([tweet.date, clean_tweet])
    except Exception as e:
        print("41 ERR %s" % e)
df = pd.DataFrame(tweets, columns=['date', 'tweet'])
# cleaning the remaining dirty tweets
#tweets_clean = df['tweet'].apply(lambda x: clean(x, fix_unicode=True, to_ascii=True, lower=True, no_line_breaks=True, no_urls=True, no_emails=True, no_phone_numbers=True, no_currency_symbols=True, no_punct=True, replace_with_url="", replace_with_email="", replace_with_phone_number="", replace_with_currency_symbol=""))

# combine date and tweet
tweet_fix = pd.concat([df['date'], df['tweet']], axis=1)

# remove duplicate tweets
tweet_fix = tweet_fix.drop_duplicates(subset=['tweet'], keep='first')

# save to csv
tweet_fix.to_csv('./data/russian_inflation.csv', index=False, header=['date', 'tweet'])